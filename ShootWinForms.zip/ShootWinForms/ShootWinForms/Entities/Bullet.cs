using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    internal class Bullet
    {
        public PictureBox BulletPictureBox { get; private set; }
        public int Speed { get; private set; }
        private static List<Bullet> bulletPool = new List<Bullet>();

        private Bullet() { }

        public void Initialize(Point startPosition, int speed, Image image)
        {
            Speed = speed;
            BulletPictureBox = BulletPictureBox ?? new PictureBox
            {
                Size = new Size(10, 20),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Tag = "bullet"
            };
            BulletPictureBox.Image = image;
            BulletPictureBox.Location = startPosition;
            BulletPictureBox.Visible = true;
        }

        public void Move()
        {
            BulletPictureBox.Top -= Speed;

            // Add bounds checking
            if (IsOffScreen())
            {
                Deactivate();
                ReturnBullet(this);
            }
        }

        public bool IsOffScreen() => BulletPictureBox.Bottom < 0 || BulletPictureBox.Top > Form.ActiveForm.ClientSize.Height;

        public void Deactivate()
        {
            if (!BulletPictureBox.IsDisposed)  // Add this check
            {
                BulletPictureBox.Visible = false;
                if (BulletPictureBox.Parent != null)
                {
                    BulletPictureBox.Parent.Controls.Remove(BulletPictureBox);
                }
            }
        }

        public static Bullet GetBullet(Point startPosition, int speed, Image image)
        {
            Bullet bullet = bulletPool.Count > 0 ? bulletPool[0] : new Bullet();
            if (bulletPool.Count > 0) bulletPool.RemoveAt(0);
            bullet.Initialize(startPosition, speed, image);
            return bullet;
        }

        public static void ReturnBullet(Bullet bullet)
        {
            if (!bulletPool.Contains(bullet))
            {
                bulletPool.Add(bullet);
            }
        }
    }
}
