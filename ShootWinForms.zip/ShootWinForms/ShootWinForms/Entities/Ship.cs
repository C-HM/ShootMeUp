﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    internal class Ship
    {
        public PictureBox ShipPictureBox { get; private set; }
        private int _speed;
        private int shootCooldown = 500;
        public static int playerLives = 5;
        private DateTime lastShotTime = DateTime.MinValue;

        public Ship(int speed)
        {
            _speed = speed;
            InitializeShip();
        }

        private void InitializeShip()
        {
            ShipPictureBox = new PictureBox();
            {
                ShipPictureBox.Size = new Size(40, 40);
                ShipPictureBox.Image = Properties.Resources.shipViolet;
                ShipPictureBox.Top = 500;
                ShipPictureBox.Left = 350;
                ShipPictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                ShipPictureBox.Tag = "player";
            };
        }

        public void MoveLeft() => ShipPictureBox.Left -= _speed;
        public void MoveRight() => ShipPictureBox.Left += _speed;
        public void AddToForm(Form form)
        {
            if (ShipPictureBox != null)
            {
                form.Controls.Add(ShipPictureBox);
            }
        }
        public Bullet Shoot()
        {
            if (DateTime.Now - lastShotTime >= TimeSpan.FromMilliseconds(shootCooldown))
            {
                lastShotTime = DateTime.Now;
                return Bullet.GetBullet(
                    new Point(ShipPictureBox.Left + (ShipPictureBox.Width / 2) - 5,
                             ShipPictureBox.Top - 20),
                    10,
                    Properties.Resources.PixelLazer // Assuming this is the bullet image
                );
            }
            return null; // Return null if we can't shoot yet
        }
    }
}
