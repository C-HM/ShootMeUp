using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

internal class Obstacle
{
    public PictureBox ObstaclePictureBox { get; private set; }
    public int Health { get; private set; }
    public bool IsDestroyed { get; private set; } // New flag
    private const int BULLET_DAMAGE = 1;

    public Obstacle(Point position, Size size, int initialHealth)
    {
        Health = initialHealth;
        IsDestroyed = false; // Initialize to false
        ObstaclePictureBox = new PictureBox
        {
            Location = position,
            Size = size,
            BackColor = Color.Gray,
            Tag = "obstacle"
        };
    }

    public bool HandleCollision(PictureBox bullet)
    {
        // Only check collision if the obstacle is not destroyed
        if (!IsDestroyed && ObstaclePictureBox.Bounds.IntersectsWith(bullet.Bounds))
        {
            TakeDamage(BULLET_DAMAGE);

            // Clean up the bullet
            if (bullet.Parent != null)
            {
                bullet.Parent.Controls.Remove(bullet);
            }
            bullet.Dispose();

            return true; // Collision occurred
        }
        return false; // No collision
    }

    public void TakeDamage(int damage)
    {
        Health -= damage;
        UpdateAppearance();

        if (Health <= 0 && !IsDestroyed)
        {
            IsDestroyed = true; // Set the flag
            // Get the parent form/control
            Control parent = ObstaclePictureBox.Parent;
            if (parent != null)
            {
                parent.Controls.Remove(ObstaclePictureBox); // Remove from parent controls
            }
            ObstaclePictureBox.Visible = false;
            ObstaclePictureBox.Dispose();
        }
    }

    private void UpdateAppearance()
    {
        // Only update appearance if not destroyed
        if (!IsDestroyed)
        {
            if (Health > 30)
                ObstaclePictureBox.BackColor = Color.Gray;
            else if (Health > 20)
                ObstaclePictureBox.BackColor = Color.DarkGray;
            else if (Health > 10)
                ObstaclePictureBox.BackColor = Color.LightGray;
            else
                ObstaclePictureBox.BackColor = Color.White;
        }
    }
}