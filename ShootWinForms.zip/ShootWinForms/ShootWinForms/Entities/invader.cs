using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    internal class Invader
    {
        public PictureBox InvaderPictureBox { get; private set; }
        protected bool CanShoot { get; private set; }

        public Invader(Size size, Image image, bool canShoot)
        {
            CanShoot = canShoot;
            InvaderPictureBox = new PictureBox
            {
                Size = size,
                Image = image,
                SizeMode = PictureBoxSizeMode.StretchImage,
                Tag = "invader"
            };
        }

        public void Move(int speed)
        {
            InvaderPictureBox.Left += speed;
            if (InvaderPictureBox.Left > 730)
            {
                InvaderPictureBox.Top += 65;
                InvaderPictureBox.Left = -80;
            }
        }

        public Bullet Shoot()
        {
            if (!CanShoot) return null;
            return Bullet.GetBullet(
                new Point(InvaderPictureBox.Left + (InvaderPictureBox.Width / 2) - 5,
                         InvaderPictureBox.Bottom + 10),
                -10,
                Properties.Resources.PixelLazer___reverse
            );
        }
    }

    internal class Blue : Invader
    {
        public Blue(Size size) : base(size, Properties.Resources.blue_removebg_preview, false) { }
    }

    internal class Red : Invader
    {
        public Red(Size size) : base(size, Properties.Resources.redinvader, true) { }
    }
}
