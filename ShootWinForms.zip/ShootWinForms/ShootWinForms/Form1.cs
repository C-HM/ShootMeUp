///ETML - Section Informatique
///Auteur : Charles-Henri Moser
///Date : 01.11.2024
///Description : Dans cette classe, il y a le programme principal du jeu.                  
///              Plusieurs options dans le jeu, soit commencer le jeu, voir les highscores,
///              les options ou bien a propos. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    public partial class Form1 : Form
    {
        private Ship playerShip;
        private InvadersManager invadersManager;
        private List<Bullet> bullets = new List<Bullet>();
        private List<Bullet> enemyBullets = new List<Bullet>();
        private List<Obstacle> obstacles = new List<Obstacle>();
        private bool goLeft;
        private bool goRight;
        private int score;
        private bool shooting;

        public Form1()
        {
            InitializeComponent();
            gameSetup();
            InitializeObstacles();

            this.KeyDown += new KeyEventHandler(this.keyisdown);
            this.KeyUp += new KeyEventHandler(this.keyisup);
            this.FormClosing += Form1_FormClosing;
        }

        private void gameSetup()
        {
            playerShip = new Ship(10);
            playerShip.AddToForm(this);

            invadersManager = new InvadersManager();
            invadersManager.InitializeInvaders(this);

            gameTimer.Tick += new EventHandler(mainGameTimerEvent);
            gameTimer.Start();
        }

        private void Form1_Load(object sender, EventArgs e) { }

        private void mainGameTimerEvent(object sender, EventArgs e)
        {
            if (goLeft) playerShip.MoveLeft();
            if (goRight) playerShip.MoveRight();

            if (playerShip.ShipPictureBox.Left <= 0)
            {
                playerShip.ShipPictureBox.Left = 0;
            }
            if (playerShip.ShipPictureBox.Right >= this.ClientSize.Width)
            {
                playerShip.ShipPictureBox.Left = this.ClientSize.Width - playerShip.ShipPictureBox.Width;
            }

            Bullet enemyBullet = invadersManager.TryEnemyShoot();
            if (enemyBullet != null)
            {
                this.Controls.Add(enemyBullet.BulletPictureBox);
                enemyBullets.Add(enemyBullet);
            }


            // Check for collisions with player
            MoveBullets();
            MoveEnemyBullets();
            CheckBulletCollisions();
            CheckBulletObstacleCollisions();
            CheckEnemyBulletCollisions();
            invadersManager.MoveInvaders(this);

            // Player shooting
            if (shooting)
            {
                Bullet newBullet = playerShip.Shoot();
                if(newBullet != null)
                {

                Bullet.GetBullet(
                    new Point(playerShip.ShipPictureBox.Left + (playerShip.ShipPictureBox.Width / 2) - 5, playerShip.ShipPictureBox.Top - 20),
                    speed: 20,
                    image: Properties.Resources.PixelLazer
                );
                if (!newBullet.BulletPictureBox.Visible) // Ensure bullet visibility
                {
                    newBullet.BulletPictureBox.Visible = true;
                }

                this.Controls.Add(newBullet.BulletPictureBox); // Directly add bullet PictureBox to form
                bullets.Add(newBullet);
                }
            }
        }

        private void MoveBullets()
        {
            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                Bullet bullet = bullets[i];
                bullet.Move();

                if (bullet.IsOffScreen())
                {
                    bullet.Deactivate();
                    Bullet.ReturnBullet(bullet);
                    bullets.RemoveAt(i);
                }
            }
        }

        private void CheckBulletCollisions()
        {
            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                Bullet bullet = bullets[i];
                if (bullet.BulletPictureBox.IsDisposed) // Add this check
                {
                    bullets.RemoveAt(i);
                    continue;
                }

                for (int j = invadersManager.InvadersList.Count - 1; j >= 0; j--)
                {
                    Invader invader = invadersManager.InvadersList[j];
                    if (invader.InvaderPictureBox.IsDisposed) // Add this check
                    {
                        invadersManager.InvadersList.RemoveAt(j);
                        continue;
                    }

                    if (bullet.BulletPictureBox.Bounds.IntersectsWith(invader.InvaderPictureBox.Bounds))
                    {
                        bullet.Deactivate();
                        Bullet.ReturnBullet(bullet);
                        bullets.RemoveAt(i);

                        this.Controls.Remove(invader.InvaderPictureBox);
                        invader.InvaderPictureBox.Dispose();
                        invadersManager.InvadersList.RemoveAt(j);

                        score++;
                        txtScore.Text = "Score: " + score;
                        break;
                    }
                }
            }
        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) goLeft = true;
            if (e.KeyCode == Keys.Right) goRight = true;
            if (e.KeyCode == Keys.Space) shooting = true;
        }

        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) goLeft = false;
            if (e.KeyCode == Keys.Right) goRight = false;
            if (e.KeyCode == Keys.Space) shooting = false;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        // In the Form1 constructor or Load event, initialize and add obstacles
        private void InitializeObstacles()
        {
            obstacles = new List<Obstacle>();

            // Define positions and sizes for three obstacles
            Point[] positions = {
            new Point(100, this.ClientSize.Height - 150),
            new Point(this.ClientSize.Width / 2 - 50, this.ClientSize.Height - 150),
            new Point(this.ClientSize.Width - 200, this.ClientSize.Height - 150)
        };
            Size obstacleSize = new Size(100, 20);

            foreach (Point position in positions)
            {
                Obstacle obstacle = new Obstacle(position, obstacleSize, initialHealth: 40);
                obstacles.Add(obstacle);
                this.Controls.Add(obstacle.ObstaclePictureBox); // Add obstacle to the form
            }
        }
        private void MoveEnemyBullets()
        {
            for (int i = enemyBullets.Count - 1; i >= 0; i--)
            {
                Bullet bullet = enemyBullets[i];
                if (bullet.BulletPictureBox.IsDisposed)
                {
                    enemyBullets.RemoveAt(i);
                    continue;
                }

                bullet.Move();

                if (bullet.BulletPictureBox.Top > this.ClientSize.Height)
                {
                    bullet.Deactivate();
                    Bullet.ReturnBullet(bullet);
                    enemyBullets.RemoveAt(i);
                }
            }
        }
        private void CheckEnemyBulletCollisions()
        {
            for (int i = enemyBullets.Count - 1; i >= 0; i--)
            {
                Bullet bullet = enemyBullets[i];
                if (bullet.BulletPictureBox.IsDisposed)
                {
                    enemyBullets.RemoveAt(i);
                    continue;
                }

                if (bullet.BulletPictureBox.Bounds.IntersectsWith(playerShip.ShipPictureBox.Bounds))
                {
                    bullet.Deactivate();
                    Bullet.ReturnBullet(bullet);
                    enemyBullets.RemoveAt(i);
                    Ship.playerLives--;
                    livesLabel.Text = "Lives: " + Ship.playerLives;
                    if (Ship.playerLives == 0)
                    {
                        GameOver();
                    }
                }
            }
        }
        private void CheckBulletObstacleCollisions()
        {
            var bulletControls = this.Controls.OfType<PictureBox>()
                .Where(x => x.Tag?.ToString() == "bullet" && !x.IsDisposed)
                .ToList();

            foreach (PictureBox bullet in bulletControls)
            {
                foreach (Obstacle obstacle in obstacles.ToList()) // Create a copy of the list
                {
                    if (obstacle.ObstaclePictureBox.IsDisposed)
                        continue;

                    if (obstacle.HandleCollision(bullet))
                    {
                        if (!bullet.IsDisposed)
                        {
                            bullet.Visible = false;
                            this.Controls.Remove(bullet);
                        }
                        break;
                    }
                }
            }
        }

        private void GameOver()
        {
            gameTimer.Stop();
            MessageBox.Show("Game Over! Score: " + score);
            this.Close();
        }
    }
}
