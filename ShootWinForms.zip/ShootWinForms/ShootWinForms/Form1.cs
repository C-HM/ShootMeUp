﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    public partial class Form1 : Form
    {
        private Ship playerShip;
        private InvadersManager invadersManager;
        private bool goLeft;
        private bool goRight;
        private int score;

        public Form1()
        {
            InitializeComponent();
            gameSetup();

            this.KeyDown += new KeyEventHandler(this.keyisdown);
            this.KeyUp += new KeyEventHandler(this.keyisup);
        }

        private void gameSetup()
        {
            playerShip = new Ship(12);
            playerShip.AddToForm(this);

            invadersManager = new InvadersManager();
            invadersManager.InitializeInvaders(this);

            gameTimer.Tick += new EventHandler(mainGameTimerEvent);
            gameTimer.Start();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Initialization code for when the form loads
        }

        private List<Bullet> bullets = new List<Bullet>();

        private void mainGameTimerEvent(object sender, EventArgs e)
        {
            // Update ship movement
            if (goLeft) playerShip.MoveLeft();
            if (goRight) playerShip.MoveRight();

            // Move bullets and remove if off-screen
            for (int i = bullets.Count - 1; i >= 0; i--)
            {
                bullets[i].Move();

                if (bullets[i].IsOffScreen())
                {
                    bullets[i].RemoveFromForm(this);
                    bullets.RemoveAt(i);
                }
            }

        }

        private void keyisdown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) goLeft = true;
            if (e.KeyCode == Keys.Right) goRight = true;
            if (e.KeyCode == Keys.Space)
            {
                Bullet newBullet = new Bullet(
                    new Point(playerShip.ShipPictureBox.Left + (playerShip.ShipPictureBox.Width / 2) - 5, playerShip.ShipPictureBox.Top - 20),
                    speed: 20,
                    image: Properties.Resources.PixelLazer
                );

                newBullet.AddToForm(this);
                bullets.Add(newBullet);
            }
        }


        private void keyisup(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left) goLeft = false;
            if (e.KeyCode == Keys.Right) goRight = false;
        }
    }
}
