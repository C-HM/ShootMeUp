﻿///ETML - Section Informatique
///Auteur : Charles-Henri Moser
///Date : 01.11.2024
///Description : Dans cette classe, on instancie un menu afin de pouvoir choisir entre
///              plusieurs options dans le jeu, soit commencer le jeu, voir les highscores,
///              les options ou bien a propos.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    /// <summary>
    /// 
    /// </summary>
    public partial class MenuForm : Form
    {
        /// <summary>
        /// 
        /// </summary>
        public MenuForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gameStart_Click(object sender, EventArgs e)
        {
            Form1 gameForm = new Form1();
            gameForm.Show();
            this.Hide();
        }

        private void hightscoreButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("High scores feature coming soon!");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

