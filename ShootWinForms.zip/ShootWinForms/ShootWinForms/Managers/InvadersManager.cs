using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShootWinForms
{
    internal class InvadersManager
    {
        public List<Invader> InvadersList { get; private set; }
        private Random random = new Random();

        public InvadersManager()
        {
            InvadersList = new List<Invader>();
        }

        public void InitializeInvaders(Form form)
        {
            for (int i = 0; i < 10; i++)
            {
                Invader invader;
                if (i % 2 == 0)
                {
                    invader = new Blue(new Size(40, 40));
                }
                else
                {
                    invader = new Red(new Size(40, 40));
                }

                // Set the position of the InvaderPictureBox directly
                invader.InvaderPictureBox.Location = new Point(i * 50, 5);

                form.Controls.Add(invader.InvaderPictureBox);
                InvadersList.Add(invader);
            }
        }

        private bool movingRight = true;

        public void MoveInvaders(Form form)
        {
            int speed = 1; // Adjust the speed as needed
            int boundaryRight = form.ClientSize.Width; // Right boundary, considering invader width
            int boundaryLeft = 0; // Left boundary

            foreach (var invader in InvadersList)
            {
                // Check if invader has reached the boundary
                if (movingRight && invader.InvaderPictureBox.Right >= boundaryRight)
                {
                    movingRight = false;
                    MoveInvadersDown(); // Move down and switch direction
                    break;
                }
                else if (!movingRight && invader.InvaderPictureBox.Left <= boundaryLeft)
                {
                    movingRight = true;
                    MoveInvadersDown(); // Move down and switch direction
                    break;
                }
                invader.Move(movingRight ? speed : -speed);
            }
        }

        // Move all invaders down
        private void MoveInvadersDown()
        {
            foreach (var invader in InvadersList)
            {
                invader.InvaderPictureBox.Top += 40;
            }
        }

        // Manage invader shooting using the bullet pool
        public Bullet InvaderShooting()
        {
            foreach (Invader invader in InvadersList)
            {
                Bullet bullet = invader.Shoot();
                if (bullet != null)
                {
                    return bullet; // Return only the first active bullet
                }
            }
            return null;
        }
        public Bullet TryEnemyShoot()
        {
            // Get only red invaders (they can shoot)
            var shootingInvaders = InvadersList.Where(i => i is Red).ToList();

            if (shootingInvaders.Count > 0 && random.Next(100) < 10) // 2% chance to shoot each frame
            {
                // Randomly select a red invader to shoot
                int index = random.Next(shootingInvaders.Count);
                return shootingInvaders[index].Shoot();
            }

            return null;
        }
    }
}
