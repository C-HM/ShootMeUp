﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Drawing;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace UnitTestProject1
{
    [TestClass]
    public class ShipTests
    {
        private Ship _ship;

        [TestInitialize]
        public void Setup()
        {
            _ship = new Ship(10); // Speed of 10
        }

        [TestMethod]
        public void Ship_InitializesCorrectly()
        {
            Assert.IsNotNull(_ship);
            Assert.IsNotNull(_ship.ShipPictureBox);
            Assert.AreEqual(40, _ship.ShipPictureBox.Width);
            Assert.AreEqual(40, _ship.ShipPictureBox.Height);
            Assert.AreEqual(500, _ship.ShipPictureBox.Top);
            Assert.AreEqual(350, _ship.ShipPictureBox.Left);
        }

        [TestMethod]
        public void Ship_MovesLeft()
        {
            int initialPosition = _ship.ShipPictureBox.Left;
            _ship.MoveLeft();
            Assert.AreEqual(initialPosition - 10, _ship.ShipPictureBox.Left);
        }

        [TestMethod]
        public void Ship_MovesRight()
        {
            int initialPosition = _ship.ShipPictureBox.Left;
            _ship.MoveRight();
            Assert.AreEqual(initialPosition + 10, _ship.ShipPictureBox.Left);
        }
    }

    [TestClass]
    public class BulletTests
    {
        [TestMethod]
        public void Bullet_InitializesCorrectly()
        {
            Point startPosition = new Point(100,
                                            100);
            int speed = 10;
            Image testImage = new Bitmap(10, 20);

            Bullet bullet = Bullet.GetBullet(startPosition, speed, testImage);

            Assert.IsNotNull(bullet);
            Assert.IsNotNull(bullet.BulletPictureBox);
            Assert.AreEqual(startPosition, bullet.BulletPictureBox.Location);
            Assert.AreEqual(speed, bullet.Speed);
        }

        [TestMethod]
        public void Bullet_MovesCorrectly()
        {
            Point startPosition = new Point(100, 100);
            int speed = 10;
            Image testImage = new Bitmap(10, 20);

            Bullet bullet = Bullet.GetBullet(startPosition, speed, testImage);
            int initialY = bullet.BulletPictureBox.Top;

            bullet.Move();

            Assert.AreEqual(initialY - speed, bullet.BulletPictureBox.Top);
        }
    }

    [TestClass]
    public class ObstacleTests
    {
        private Obstacle _obstacle;

        [TestInitialize]
        public void Setup()
        {
            Point position = new Point(100, 100);
            Size size = new Size(100, 20);
            _obstacle = new Obstacle(position, size, 40);
        }

        [TestMethod]
        public void Obstacle_InitializesCorrectly()
        {
            Assert.IsNotNull(_obstacle);
            Assert.IsNotNull(_obstacle.ObstaclePictureBox);
            Assert.AreEqual(40, _obstacle.Health);
            Assert.IsFalse(_obstacle.IsDestroyed);
        }

        [TestMethod]
        public void Obstacle_TakesDamage()
        {
            int initialHealth = _obstacle.Health;
            _obstacle.TakeDamage(10);
            Assert.AreEqual(initialHealth - 10, _obstacle.Health);
        }

        [TestMethod]
        public void Obstacle_IsDestroyedAtZeroHealth()
        {
            _obstacle.TakeDamage(40); // Initial health is 40
            Assert.IsTrue(_obstacle.IsDestroyed);
        }
    }

    [TestClass]
    public class InvaderTests
    {
        [TestMethod]
        public void Invader_InitializesCorrectly()
        {
            Size size = new Size(40, 40);
            Image testImage = new Bitmap(40, 40);
            Invader invader = new Invader(size, testImage, true);

            Assert.IsNotNull(invader);
            Assert.IsNotNull(invader.InvaderPictureBox);
            Assert.AreEqual(size, invader.InvaderPictureBox.Size);
            Assert.AreEqual("invader", invader.InvaderPictureBox.Tag);
        }

        [TestMethod]
        public void RedInvader_CanShoot()
        {
            Red redInvader = new Red(new Size(40, 40));
            Bullet bullet = redInvader.Shoot();
            Assert.IsNotNull(bullet);
        }

        [TestMethod]
        public void BlueInvader_CannotShoot()
        {
            Blue blueInvader = new Blue(new Size(40, 40));
            Bullet bullet = blueInvader.Shoot();
            Assert.IsNull(bullet);
        }
    }
}
